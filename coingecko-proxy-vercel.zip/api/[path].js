export default async function handler(req, res) {
  const path = req.query.path?.join("/") || "";
  const targetUrl = `https://api.coingecko.com/api/v3/${path}${req.url.split("?")[1] ? "?" + req.url.split("?")[1] : ""}`;
  
  try {
    const response = await fetch(targetUrl, {
      headers: { "Accept": "application/json" }
    });
    const data = await response.json();
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.status(response.status).json(data);
  } catch (err) {
    res.status(500).json({ error: "Proxy error", details: err.message });
  }
}
